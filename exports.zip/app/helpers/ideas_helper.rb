module IdeasHelper
end
