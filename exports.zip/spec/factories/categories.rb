FactoryBot.define do
  factory :category do
    name { "サンプルカテゴリー" }
  end
end
